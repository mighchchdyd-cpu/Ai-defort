import "dotenv/config";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { parse as parseCookie } from "cookie";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { getSessionCookieOptions } from "./cookies";
import { serveStatic, setupVite } from "./vite";

type ChatMessage = { role: "user" | "assistant" | "system"; content: string };
const ACCESS_COOKIE = "defort_access_session";
const ACCESS_TTL_MS = 1000 * 60 * 60 * 24 * 30;

function accessKey() {
  return process.env.MANUS_JWT_SECRET || process.env.DEFORT_ACCESS_CODE || "";
}

function signAccessPayload(payload: string) {
  return createHmac("sha256", accessKey()).update(payload).digest("base64url");
}

function createAccessToken() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + ACCESS_TTL_MS, nonce: randomBytes(18).toString("hex") })).toString("base64url");
  return `${payload}.${signAccessPayload(payload)}`;
}

function hasValidAccess(req: express.Request) {
  const token = parseCookie(req.headers.cookie || "")[ACCESS_COOKIE] || String(req.headers["x-defort-access"] || "");
  if (!token || !accessKey()) return false;
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return false;
  const expected = signAccessPayload(payload);
  if (signature.length !== expected.length) return false;
  try {
    if (!timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return false;
    const claims = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { exp?: number };
    return typeof claims.exp === "number" && claims.exp > Date.now();
  } catch {
    return false;
  }
}

function correctAccessCode(value: unknown) {
  const expected = process.env.DEFORT_ACCESS_CODE || "";
  const provided = typeof value === "string" ? value.trim() : "";
  if (!expected || !provided || expected.length !== provided.length) return false;
  return timingSafeEqual(Buffer.from(provided), Buffer.from(expected));
}

function inferTaskFocus(messages: ChatMessage[]) {
  const prompt = messages.filter((message) => message.role === "user").map((message) => message.content).join(" ").toLowerCase();
  if (/برومبت|prompt|تعليمة|تعليمات/.test(prompt)) return "توجيه المهمة: هذه مهمة تصميم برومبت. حسّن الهدف والسياق والمتغيرات والقيود وشكل المخرجات، ثم قدم نسخة جاهزة ومعايير اختبار.";
  if (/فكك|تفكيك|فك تشفير|مموه|obfuscat|deobfuscat|decode|lua|python|javascript|js|bytecode/.test(prompt)) return "توجيه المهمة: هذه مهمة تحليل ساكن لكود مملوك أو مصرح بفحصه. حدّد اللغة ونوع التمويه، استخرج السلاسل والعمليات، أعد تسمية الرموز، تتبع التدفق، ثم أعد كتابة نسخة مقروءة مع درجة ثقة ولا تشغّل الكود.";
  if (/كود|برمج|code|debug|bug|react|python|javascript|typescript|api|قاعدة بيانات/.test(prompt)) return "توجيه المهمة: هذه مهمة هندسية. افحص التقنية المطلوبة، صحة التنفيذ، الحالات الطرفية، الأمان، الأداء، الاختبارات، وخطوات التشغيل.";
  if (/اكتب|كتابة|مقال|محتوى|صياغ|سيناريو|رسالة|إعلان/.test(prompt)) return "توجيه المهمة: هذه مهمة كتابة. حدّد الجمهور والهدف والنبرة، ثم اكتب نصًا جاهزًا مع تحسين البنية والوضوح والإقناع.";
  if (/حلل|تحليل|قارن|قرار|استراتيجي|خطة|مشروع|فكرة/.test(prompt)) return "توجيه المهمة: هذه مهمة تحليل وتخطيط. افصل الحقائق عن الافتراضات، قارن البدائل، اذكر المخاطر، ثم قدم توصية وخطوات تنفيذ.";
  return "توجيه المهمة: صنّف الطلب أولًا، ثم اختر أسلوب الإجابة الأنسب بدل استخدام قالب واحد لكل الأسئلة.";
}

type ResearchItem = { source: string; title: string; url: string; snippet: string };

async function searchResearch(messages: ChatMessage[]): Promise<ResearchItem[]> {
  const query = messages.filter((message) => message.role === "user").at(-1)?.content?.trim();
  if (!query) return [];
  const safeJson = async (url: string) => {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(7000), headers: { Accept: "application/json", "User-Agent": "DEFORT-AI-Research/1.0" } });
      return response.ok ? await response.json() as any : null;
    } catch {
      return null;
    }
  };
  const encoded = encodeURIComponent(query);
  const [duck, wiki, stack, github] = await Promise.all([
    safeJson(`https://api.duckduckgo.com/?q=${encoded}&format=json&no_html=1&skip_disambig=1`),
    safeJson(`https://en.wikipedia.org/w/rest.php/v1/search/page?q=${encoded}&limit=5`),
    safeJson(`https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encoded}&site=stackoverflow&pagesize=5`),
    safeJson(`https://api.github.com/search/repositories?q=${encoded}&sort=stars&order=desc&per_page=5`),
  ]);
  const results: ResearchItem[] = [];
  if (duck?.AbstractText && duck?.AbstractURL) results.push({ source: "DuckDuckGo", title: duck.Heading || "Web result", url: duck.AbstractURL, snippet: duck.AbstractText });
  for (const page of wiki?.pages || []) if (page?.title && page?.key) results.push({ source: "Wikipedia", title: page.title, url: `https://en.wikipedia.org/wiki/${page.key}`, snippet: page.description || page.excerpt || "Wikipedia result" });
  for (const item of stack?.items || []) if (item?.title && item?.link) results.push({ source: "Stack Overflow", title: item.title.replace(/<[^>]+>/g, ""), url: item.link, snippet: `إجابة أو سؤال تقني بدرجة ${item.score ?? 0} ومشاهدات ${item.view_count ?? 0}` });
  for (const repo of github?.items || []) if (repo?.full_name && repo?.html_url) results.push({ source: "GitHub", title: repo.full_name, url: repo.html_url, snippet: repo.description || `مستودع عام بعدد نجوم ${repo.stargazers_count ?? 0}` });
  return results.slice(0, 16);
}

async function callPlatformLLM(model: string | undefined, messages: ChatMessage[], developerMode: boolean, research: boolean, reverse: boolean) {
  const apiUrl = process.env.MANUS_API_URL;
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) throw new Error("خدمة الذكاء الاصطناعي غير مهيأة في الخادم");

  const profile = model === "defort-code"
    ? "ركز أكثر على هندسة البرمجيات: افحص المتطلبات والواجهات والأنواع والأخطاء والحالات الطرفية والأمان والأداء والاختبارات. عندما تكتب كودًا، اجعله قابلًا للتشغيل ومتكاملًا واذكر الملفات والتغييرات بوضوح."
    : model === "defort-fast"
      ? "كن موجزًا وسريعًا مع الحفاظ على الدقة؛ قدم الإجابة العملية أولًا، ثم التفاصيل عند الحاجة."
      : model === "defort-write"
        ? "ركز على كتابة عربية أو إنجليزية طبيعية، قوية، مناسبة للجمهور، وجاهزة للاستخدام؛ لا تكتفِ بالنقد النظري."
        : model === "defort-prompt"
          ? "ركز على هندسة البرومبتات القابلة لإعادة الاستخدام، وقدم النسخة النهائية مع متغيرات وتعليمات إخراج ومعايير تقييم."
          : model === "defort-reverse"
            ? "ركز على التحليل الساكن وفك التمويه المصرح به في Lua وPython وJavaScript وغيرها: استنتج اللغة، فك السلاسل والطبقات، أعد تسمية المتغيرات، اشرح التدفق، وأعد كتابة الكود مع الحفاظ على السلوك المتوقع ودرجة ثقة لكل استنتاج. لا تشغّل الكود ولا تساعد على تجاوز DRM أو سرقة مفاتيح أو إخفاء برمجيات ضارة."
          : "استخدم أعلى جودة تحليلية متاحة للمهمة، ووازن بين العمق والوضوح دون حشو.";
  const taskFocus = inferTaskFocus(messages);
  const reverseContext = reverse
    ? "وضع DEFORT Reverse مفعّل. حلّل النص تحليلًا ساكنًا فقط. افصل بين فك الترميز (encoding)، وفك الضغط، والتمويه، والتشفير الحقيقي الذي يحتاج مفتاحًا. اطلب الكود أو الجزء الناقص عند الحاجة. قدم: نوع اللغة، ملخص السلوك، مؤشرات التمويه، نسخة مقروءة، خريطة تحويل الرموز، المخاطر، ودرجة الثقة. لا تشغّل السكربت، لا تستخرج أسرارًا غير مصرّح بها، ولا تقدم إرشادات لتجاوز حماية أو DRM أو إخفاء حمولة ضارة."
    : "";
  const researchItems = research ? await searchResearch(messages) : [];
  const researchContext: ChatMessage | null = research
    ? { role: "system", content: researchItems.length
      ? `وضع البحث الشامل مفعّل. استخدم المصادر التالية كمواد بحث، لا كحقيقة مطلقة. قارن بينها، اذكر روابط المصادر في قسم "المصادر"، ميّز بين ما تقوله المصادر وما تستنتجه، ولا تخترع مصادر أو روابط.\n${researchItems.map((item, index) => `[${index + 1}] ${item.source} — ${item.title}\nالرابط: ${item.url}\nالملخص: ${item.snippet}`).join("\n\n")}`
      : "وضع البحث الشامل مفعّل لكن لم تعد مصادر عامة في الوقت المحدد. صرّح بذلك بوضوح ولا توهم المستخدم بأنك بحثت." }
    : null;

  const system: ChatMessage = {
    role: "system",
    content: `أنت DEFORT AI — مهندس ومفكر وكاتب ومصمم برومبتات محترف. هدفك تقديم أفضل إجابة عملية ودقيقة، لا مجرد كلام عام.

منهج العمل الإلزامي:
1) افهم نية المستخدم والنتيجة المطلوبة، وحدد الغموض والتناقضات قبل الحل.
2) فكك المهمة إلى متطلبات وقيود وافتراضات، ثم اختر الحل الأبسط الذي يحقق الهدف.
3) فكّر داخليًا بعمق، لكن لا تعرض سلسلة التفكير الخاصة أو ملاحظاتك السرية؛ اعرض بدلًا منها خلاصة منطقية قابلة للتحقق، والقرارات المهمة، والافتراضات.
4) نفّذ الإجابة بوضوح. في البرمجة قدّم كودًا كاملًا متماسكًا، متوافقًا مع التقنية المطلوبة، مع معالجة الأخطاء والأمان والاختبارات أو خطوات التحقق.
5) راجع النتيجة قبل إرسالها: تحقق من صحة المنطق، أسماء المتغيرات، الحالات الطرفية، قابلية التنفيذ، وعدم وجود ادعاء لم تنفذه فعليًا.

قواعد الخبرة:
- لا تخترع APIs أو مكتبات أو نتائج أو ملفات أو اختبارات. إذا لم تعرف أو لم تتوفر أداة، قل ذلك بوضوح واقترح بديلًا عمليًا.
- ميّز بين الحقيقة والافتراض والاقتراح. اسأل سؤالًا توضيحيًا فقط عندما يمنع الغموض تنفيذ حل صحيح؛ وإلا اتخذ افتراضًا معقولًا واذكره.
- عند مراجعة كود، ابدأ بالمشكلات ذات الخطورة الأعلى، اشرح السبب، ثم قدم الإصلاح.
- عند بناء مشروع، أعطِ بنية ملفات، عقود الواجهات، تدفق البيانات، الأمان، ثم التنفيذ والتشغيل والتحقق.
- عند الكتابة، حسّن الفكرة والبنية والنبرة والجمهور، وقدم نصًا جاهزًا للنشر بدل نصائح عامة.
- عند تصميم برومبت، استخدم: الدور، السياق، المهمة، القيود، المدخلات، شكل المخرجات، ومعايير الجودة؛ اجعله قابلًا لإعادة الاستخدام واذكر طريقة تقييمه.
- لا تخلط بين بيئات البرمجة مثل React وNode وRoblox وUnity وGodot؛ صرّح بالتوافق.
- احترم الخصوصية والأمان ولا تطلب مفاتيح سرية داخل المحادثة.

${developerMode ? "أنت الآن في DEFORT Developer Mode: تعامل مع الطلب كمسؤولية هندسية كاملة، وركّز على المعمارية والتنفيذ والاختبار وتصحيح الأخطاء." : "أنت الآن في وضع DEFORT العام: اجمع بين الذكاء العملي والكتابة الواضحة والخبرة التقنية عند الحاجة."}
${profile}
${taskFocus}
${reverseContext}

أجب بلغة المستخدم، وبالعربية افتراضيًا. استخدم عناوين ونقاط مختصرة عندما تساعد، ولا تكرر السؤال أو تقدم مقدمات فارغة.`,
  };
  const upstream = await fetch(`${apiUrl.replace(/\/$/, "")}/v1/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: undefined, messages: [system, ...(researchContext ? [researchContext] : []), ...messages], stream: false }),
  });
  const payload = await upstream.json().catch(() => ({}));
  if (!upstream.ok || payload.error) {
    const message = typeof payload?.error?.message === "string" ? payload.error.message : "تعذر الحصول على رد من محرك الذكاء الاصطناعي";
    throw new Error(message);
  }
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content.trim()) throw new Error("عاد المحرك دون نص قابل للعرض");
  if (!research || !researchItems.length) return content;
  const sources = researchItems.map((item, index) => `${index + 1}. ${item.source} — ${item.title}\n   ${item.url}`).join("\n");
  return `${content.trim()}\n\n### المصادر التي جرى الرجوع إليها\n${sources}`;
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.get("/api/access/status", (req, res) => res.json({ authenticated: hasValidAccess(req) }));
  app.post("/api/access/login", (req, res) => {
    if (!correctAccessCode(req.body?.code)) return res.status(401).json({ error: "رمز الدخول غير صحيح" });
    const accessToken = createAccessToken();
    res.cookie(ACCESS_COOKIE, accessToken, { ...getSessionCookieOptions(req), maxAge: ACCESS_TTL_MS });
    return res.json({ authenticated: true, accessToken });
  });
  app.post("/api/access/logout", (req, res) => {
    res.clearCookie(ACCESS_COOKIE, getSessionCookieOptions(req));
    return res.json({ authenticated: false });
  });
  app.post("/api/chat", (req, res, next) => {
    if (!hasValidAccess(req)) return res.status(401).json({ error: "يلزم إدخال رمز الدخول أولًا" });
    return next();
  }, async (req, res) => {
    const body = req.body as { model?: string; developerMode?: boolean; research?: boolean; reverse?: boolean; messages?: ChatMessage[] };
    if (!Array.isArray(body.messages) || body.messages.length === 0) return res.status(400).json({ error: "أرسل رسالة واحدة على الأقل" });
    const messages = body.messages.filter((message) => message && ["user", "assistant", "system"].includes(message.role) && typeof message.content === "string" && message.content.trim()).slice(-30);
    if (!messages.length) return res.status(400).json({ error: "محتوى الرسالة غير صالح" });
    try {
      const message = await callPlatformLLM(body.model, messages, Boolean(body.developerMode), Boolean(body.research), Boolean(body.reverse));
      return res.json({ message });
    } catch (error) {
      console.error("[Chat] completion failed:", error);
      return res.status(502).json({ error: error instanceof Error ? error.message : "فشل الاتصال بمحرك الذكاء الاصطناعي" });
    }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
