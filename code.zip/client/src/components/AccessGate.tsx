import { FormEvent, ReactNode, useEffect, useState } from "react";
import { ArrowUp, LockKeyhole, ShieldCheck, Sparkles } from "lucide-react";
import { accessHeaders, saveAccessToken } from "@/lib/access";

type AccessGateProps = { children: ReactNode };

type AccessState = "checking" | "locked" | "unlocked";

export default function AccessGate({ children }: AccessGateProps) {
  const [state, setState] = useState<AccessState>("checking");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    fetch("/api/access/status", { credentials: "include", headers: accessHeaders() })
      .then((response) => response.json())
      .then((payload: { authenticated?: boolean }) => {
        if (active) setState(payload.authenticated ? "unlocked" : "locked");
      })
      .catch(() => {
        if (active) {
          setState("locked");
          setError("تعذر التحقق من جلسة الدخول. حاول مرة أخرى.");
        }
      });
    return () => { active = false; };
  }, []);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!code.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/access/login", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim() }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || "رمز الدخول غير صحيح");
      if (typeof payload.accessToken === "string") saveAccessToken(payload.accessToken);
      setState("unlocked");
      setCode("");
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : "تعذر تسجيل الدخول");
    } finally {
      setBusy(false);
    }
  };

  if (state === "checking") {
    return <div className="access-screen"><div className="access-loader"><span /><span /><span /></div><p>جاري تأمين مساحة DEFORT...</p></div>;
  }

  if (state === "unlocked") return <>{children}</>;

  return (
    <div className="access-screen" dir="rtl">
      <div className="access-glow" />
      <section className="access-card">
        <div className="access-brand"><div className="access-mark">D</div><div><b>DEFORT</b><small>Beyond Intelligence</small></div></div>
        <div className="access-icon"><LockKeyhole size={23} /></div>
        <span className="access-kicker"><Sparkles size={13} /> مساحة خاصة ومحمية</span>
        <h1>أدخل رمز الوصول</h1>
        <p>هذه المساحة مخصصة لك. أدخل الرمز لبدء جلسة DEFORT AI.</p>
        <form onSubmit={submit}>
          <label htmlFor="defort-access-code">رمز الدخول</label>
          <input id="defort-access-code" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 12))} placeholder="•••" aria-describedby={error ? "access-error" : undefined} autoFocus />
          {error && <div id="access-error" className="access-error"><ShieldCheck size={14} /> {error}</div>}
          <button type="submit" disabled={busy || !code.trim()}>{busy ? "جارٍ التحقق..." : "دخول إلى DEFORT"}<ArrowUp size={17} /></button>
        </form>
        <div className="access-foot"><ShieldCheck size={13} /> التحقق يتم بأمان على الخادم</div>
      </section>
    </div>
  );
}
