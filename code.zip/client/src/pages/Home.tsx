import { useMemo, useRef, useState } from "react";
import {
  Archive,
  ArrowUp,
  Binary,
  Bot,
  Check,
  ChevronDown,
  Code2,
  Compass,
  Copy,
  FileCode2,
  FileText,
  FolderKanban,
  GitBranch,
  Globe2,
  Grid2X2,
  History,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Paperclip,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Square,
  Terminal,
  X,
  Zap,
} from "lucide-react";
import { accessHeaders } from "@/lib/access";

type Role = "user" | "assistant";
type Message = { id: string; role: Role; text: string; time: string; attachment?: string };
type Thread = { id: string; title: string; preview: string; messages: Message[] };

const now = () => new Intl.DateTimeFormat("ar-SA", { hour: "2-digit", minute: "2-digit" }).format(new Date());

const initialThreads: Thread[] = [
  {
    id: "launch",
    title: "منصة DEFORT AI",
    preview: "كيف يمكنني مساعدتك اليوم؟",
    messages: [
      {
        id: "welcome",
        role: "assistant",
        time: now(),
        text: "مرحباً، أنا **DEFORT**.\n\nأحوّل الأفكار المعقدة إلى خطوات واضحة، بنية متينة، ومنتج قابل للبناء. ابدأ بسؤال، فكرة مشروع، أو ملف تريد تحليله.",
      },
    ],
  },
  { id: "landing", title: "Landing page جديدة", preview: "مراجعة هيكل الصفحة والـ CTA", messages: [] },
  { id: "roblox", title: "نظام مهام Roblox", preview: "تصميم منطق المهام وحفظ التقدم", messages: [] },
];

const modelOptions = [
  { id: "defort-pro", label: "DEFORT Pro", note: "الأفضل للمشاريع" },
  { id: "defort-fast", label: "DEFORT Fast", note: "سريع للمهام اليومية" },
  { id: "defort-code", label: "DEFORT Code", note: "هندسة وبرمجة" },
  { id: "defort-write", label: "DEFORT Write", note: "كتابة وصياغة" },
  { id: "defort-prompt", label: "DEFORT Prompt", note: "تصميم البرومبتات" },
  { id: "defort-reverse", label: "DEFORT Reverse", note: "تفكيك Lua / Python / JS" },
];

function renderMessage(text: string) {
  return text.split("\n").map((line, index) => {
    const code = line.startsWith("```") ? line.replaceAll("```", "") : "";
    if (line.startsWith("```") || code) return code ? <code key={index}>{code}</code> : null;
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    return <span key={index}>{parts.map((part, i) => part.startsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : part)}{index < text.split("\n").length - 1 && <br />}</span>;
  });
}

export default function Home() {
  const [threads, setThreads] = useState(initialThreads);
  const [activeId, setActiveId] = useState("launch");
  const [input, setInput] = useState("");
  const [model, setModel] = useState(modelOptions[0]);
  const [modelOpen, setModelOpen] = useState(false);
  const [developerMode, setDeveloperMode] = useState(false);
  const [researchMode, setResearchMode] = useState(false);
  const [reverseMode, setReverseMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [thinking, setThinking] = useState(false);
  const [attachment, setAttachment] = useState<string>();
  const [copied, setCopied] = useState<string>();
  const [error, setError] = useState<string>();
  const fileRef = useRef<HTMLInputElement>(null);
  const active = threads.find((thread) => thread.id === activeId) ?? threads[0];
  const filteredThreads = useMemo(() => threads.filter((thread) => `${thread.title} ${thread.preview}`.toLowerCase().includes(search.toLowerCase())), [threads, search]);

  const updateActive = (messages: Message[]) => setThreads((current) => current.map((thread) => thread.id === activeId ? { ...thread, messages, preview: messages.at(-1)?.text.slice(0, 45) ?? thread.preview } : thread));

  const newChat = () => {
    const id = `chat-${Date.now()}`;
    setThreads((current) => [{ id, title: "محادثة جديدة", preview: "ابدأ محادثة جديدة", messages: [] }, ...current]);
    setActiveId(id);
    setInput("");
    setError(undefined);
    setSidebarOpen(false);
  };

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || thinking) return;
    const userMessage: Message = { id: `user-${Date.now()}`, role: "user", text, time: now(), attachment };
    const nextMessages = [...active.messages, userMessage];
    updateActive(nextMessages);
    setInput("");
    setAttachment(undefined);
    setError(undefined);
    setThinking(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", ...accessHeaders() },
        body: JSON.stringify({ model: model.id, developerMode, research: researchMode, reverse: reverseMode, messages: nextMessages.map(({ role, text: content }) => ({ role, content })) }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "تعذر الاتصال بالمحرك");
      updateActive([...nextMessages, { id: `assistant-${Date.now()}`, role: "assistant", text: payload.message, time: now() }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ غير متوقع");
    } finally {
      setThinking(false);
    }
  };

  const stopThinking = () => setThinking(false);
  const copyMessage = async (id: string, text: string) => { await navigator.clipboard?.writeText(text); setCopied(id); window.setTimeout(() => setCopied(undefined), 1400); };

  return (
    <div className="defort-shell" dir="rtl">
      <aside className={`sidebar ${sidebarOpen ? "is-open" : ""}`}>
        <div className="brand-row">
          <div className="brand-mark"><span>D</span></div>
          <div><div className="brand-name">DEFORT</div><div className="brand-tag">Beyond Intelligence</div></div>
          <button className="icon-btn mobile-close" onClick={() => setSidebarOpen(false)} aria-label="إغلاق القائمة"><X size={18} /></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={17} /> محادثة جديدة <span>⌘ K</span></button>
        <nav className="nav-list">
          <button className="nav-item active"><MessageSquare size={17} /> المحادثات <em>{threads.length}</em></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="user-card"><div className="avatar">م</div><div><b>محمد نواف</b><small>مساحة شخصية</small></div><MoreHorizontal size={17} /></div>
        </div>
      </aside>
      {sidebarOpen && <button className="sidebar-scrim" onClick={() => setSidebarOpen(false)} aria-label="إغلاق القائمة" />}

      <main className="main-panel">
        <header className="topbar">
          <div className="topbar-start"><button className="icon-btn menu-button" onClick={() => setSidebarOpen(true)} aria-label="فتح القائمة"><Menu size={20} /></button><div className="crumb"><span>المحادثات</span><i>/</i><strong>{active.title}</strong></div></div>
          <div className="topbar-end"><div className="connection"><span className="status-pulse" /> النظام متصل</div><button className="icon-btn" aria-label="استكشاف"><Compass size={18} /></button><button className="profile-dot">م</button></div>
        </header>

        <section className="chat-stage">
          <div className="chat-toolbar"><div><div className="eyebrow"><span className="gold-line" /> جلسة عمل نشطة</div><h1>{reverseMode ? "DEFORT Reverse" : developerMode ? "DEFORT Developer Mode" : active.title}</h1></div><div className="toolbar-actions"><button className={`dev-toggle ${reverseMode ? "selected" : ""}`} onClick={() => setReverseMode((value) => !value)}><Binary size={15} /> تفكيك سكربت <span className="toggle-track"><span /></span></button><button className={`dev-toggle ${researchMode ? "selected" : ""}`} onClick={() => setResearchMode((value) => !value)}><Globe2 size={15} /> بحث شامل <span className="toggle-track"><span /></span></button><button className={`dev-toggle ${developerMode ? "selected" : ""}`} onClick={() => setDeveloperMode((value) => !value)}><Code2 size={15} /> المطوّر <span className="toggle-track"><span /></span></button><button className="icon-btn" aria-label="خيارات"><MoreHorizontal size={19} /></button></div></div>

          <div className="messages-area">
            {active.messages.length === 0 && <div className="empty-state"><div className="empty-orb"><Sparkles size={24} /></div><h2>ما الذي ستبنيه اليوم؟</h2><p>صف فكرتك، وسأساعدك على تحويلها إلى خطة، كود، أو منتج قابل للتنفيذ.</p><div className="prompt-grid"><button onClick={() => setInput("صمّم لي بنية مشروع SaaS متكاملة")}>بنية مشروع SaaS <ArrowUp size={14} /></button><button onClick={() => setInput("راجع هذا الكود وابحث عن الأخطاء")}>مراجعة كود <ArrowUp size={14} /></button><button onClick={() => setInput("أنشئ خطة إطلاق لمنتج رقمي")}>خطة إطلاق <ArrowUp size={14} /></button></div></div>}
            {active.messages.map((message) => <article key={message.id} className={`message ${message.role}`}><div className="message-avatar">{message.role === "assistant" ? <div className="mini-mark">D</div> : "م"}</div><div className="message-body"><div className="message-meta"><b>{message.role === "assistant" ? "DEFORT" : "أنت"}</b><span>{message.time}</span>{message.role === "assistant" && <span className="verified"><Check size={11} /> موثّق</span>}</div><div className="message-copy">{renderMessage(message.text)}</div>{message.attachment && <div className="attachment-chip"><FileText size={14} /> {message.attachment}</div>}{message.role === "assistant" && <div className="message-actions"><button onClick={() => copyMessage(message.id, message.text)}>{copied === message.id ? <Check size={13} /> : <Copy size={13} />} {copied === message.id ? "تم النسخ" : "نسخ"}</button><button><GitBranch size={13} /> متابعة</button></div>}</div></article>)}
            {thinking && <div className="thinking-row"><div className="message-avatar"><div className="mini-mark">D</div></div><div className="thinking-card"><div className="thinking-title"><span className="thinking-dots"><i /><i /><i /></span> DEFORT يفكر في الخطوة التالية</div><small>{reverseMode ? "يفكك البنية ويحدد التمويه دون تشغيل السكربت..." : researchMode ? "يبحث في مصادر متعددة ويقارن النتائج..." : developerMode ? "يفحص المتطلبات وبنية الحل..." : "يحلل سؤالك ويجهز إجابة دقيقة..."}</small></div></div>}
            {error && <div className="error-banner"><ShieldCheck size={16} /><div><b>لم تكتمل العملية</b><span>{error}</span></div><button onClick={() => setError(undefined)}><X size={15} /></button></div>}
          </div>

          <div className="composer-wrap"><div className="composer"><textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); } }} placeholder={developerMode ? "صف المهمة البرمجية أو ارفع ملفات المشروع..." : "اسأل DEFORT أي شيء..."} rows={2} /><div className="composer-bottom"><div className="composer-tools"><input ref={fileRef} type="file" hidden onChange={(event) => setAttachment(event.target.files?.[0]?.name)} /><button className="tool-button" onClick={() => fileRef.current?.click()}><Paperclip size={16} /> إرفاق</button><div className="model-picker"><button className="tool-button model-trigger" onClick={() => setModelOpen((value) => !value)}><Bot size={16} /><span>{model.label}</span><ChevronDown size={14} /></button>{modelOpen && <div className="model-menu">{modelOptions.map((option) => <button key={option.id} onClick={() => { setModel(option); setModelOpen(false); }} className={option.id === model.id ? "chosen" : ""}><span><b>{option.label}</b><small>{option.note}</small></span>{option.id === model.id && <Check size={15} />}</button>)}</div>}</div>{attachment && <span className="file-pill"><FileCode2 size={13} /> {attachment}<button onClick={() => setAttachment(undefined)}><X size={12} /></button></span>}</div><div className="composer-meta"><span>Enter للإرسال · Shift + Enter لسطر جديد</span>{developerMode && <span className="mode-label"><Terminal size={12} /> سياق المطوّر نشط</span>}</div><button className={`send-button ${thinking ? "stop" : ""}`} onClick={thinking ? stopThinking : sendMessage} aria-label={thinking ? "إيقاف" : "إرسال"}>{thinking ? <Square size={15} fill="currentColor" /> : <ArrowUp size={19} />}</button></div></div><div className="composer-footnote"><span><ShieldCheck size={13} /> محادثتك خاصة ومحمية</span><span>DEFORT AI · 2026</span></div></div>
        </section>
      </main>
      <div className="search-hint"><Search size={13} /> اضغط للبحث <kbd>⌘</kbd><kbd>K</kbd></div>
      <div className="sr-only"><label htmlFor="chat-search">البحث في المحادثات</label><input id="chat-search" value={search} onChange={(event) => setSearch(event.target.value)} /></div>
    </div>
  );
}
