const ACCESS_TOKEN_KEY = "defort-access-token";

export function readAccessToken() {
  try {
    return sessionStorage.getItem(ACCESS_TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function saveAccessToken(token: string) {
  try {
    sessionStorage.setItem(ACCESS_TOKEN_KEY, token);
  } catch {
    // Cookie authentication remains available when sessionStorage is blocked.
  }
}

export function accessHeaders(): Record<string, string> {
  const token = readAccessToken();
  return token ? { "X-Defort-Access": token } : {};
}
